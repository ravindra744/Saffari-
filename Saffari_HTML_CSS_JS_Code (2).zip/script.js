let coins = 0;
let level = 1;
let position = 0;

function moveCar() {
  position += 100;
  coins += 100;
  if (coins >= 1000) {
    level++;
    coins = 0;
  }

  document.getElementById('car').style.transform = `translateX(${position}px)`;
  document.getElementById('status').innerText = `Level: ${level} | Coins: ${coins}`;
}
